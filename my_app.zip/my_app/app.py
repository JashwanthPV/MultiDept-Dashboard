from flask import Flask, render_template

app = Flask(__name__)

def load_departments(file_path='departments.txt'):
    departments = []
    with open(file_path, 'r') as file:
        for line in file:
            department_name = line.strip()
            if department_name:
                departments.append(department_name)
    print ("departments=", departments)
    return departments

# Load departments from the file at startup
departments = load_departments()
print (departments)

@app.route('/')
def index():
    return render_template('index.html', departments=departments)

@app.route('/dashboard/<department_name>')
def department_dashboard(department_name):
    if department_name in departments:
        return render_template('department_dashboard.html', department_name=department_name)
    else:
        return "Department not found", 404

if __name__ == '__main__':
    app.run(debug=True)
